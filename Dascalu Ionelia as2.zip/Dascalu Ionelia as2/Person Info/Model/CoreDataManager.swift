import Foundation
import CoreData
import UIKit

// Singleton class to have only one instance in the whole app
class CoreDataManager {
  
  static let sharedManager = CoreDataManager()
  
  var contextHasChanged : Bool

  private init() {
      contextHasChanged = false
  } // Prevent clients from creating another instance.
  
  lazy var persistentContainer: NSPersistentContainer = {
    
    let container = NSPersistentContainer(name: "PersonModel")
    
    
    container.loadPersistentStores(completionHandler: { (storeDescription, error) in
      
      if let error = error as NSError? {
        fatalError("Unresolved error \(error), \(error.userInfo)")
      }
    })
    return container
  }()
  
  //4
  func saveContext () {
    let context = CoreDataManager.sharedManager.persistentContainer.viewContext
    if context.hasChanges {
      do {
        try context.save()
      } catch {
        // Replace this implementation with code to handle the error appropriately.
        // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        let nserror = error as NSError
        fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
      }
    }
  }
    
    func transformEntitiesToModels(data:[DBPerson]) -> [Person]{
        
        var people = [Person]()
        
        for person in data {
            var newPerson = Person()
            
            newPerson.name = person.personName!
            newPerson.years = person.personYears!
            newPerson.birthplace = person.personBirthplace!
            newPerson.description = person.personDescription!
            newPerson.image = person.personImage!
            newPerson.url = person.personUrl!
            
            people.append(newPerson)
        }
        
        return people
    }
    
    func transformEntitiesToModels(data:[DBFavoritePerson]) -> [Person]{
        
        var favoritePeople = [Person]()
        
        for favoritePerson in data {
            var newPerson = Person()
            
            newPerson.name = favoritePerson.favoritePersonName!
            newPerson.years = favoritePerson.favoritePersonYears!
            newPerson.birthplace = favoritePerson.favoritePersonBirthplace!
            newPerson.description = favoritePerson.favoritePersonDescription!
            newPerson.image = favoritePerson.favoritePersonImage!
            newPerson.url = favoritePerson.favoritePersonUrl!
            
            favoritePeople.append(newPerson)
        }
        
        return favoritePeople
    }

}
