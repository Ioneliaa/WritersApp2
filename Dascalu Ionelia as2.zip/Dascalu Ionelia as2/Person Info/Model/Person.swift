//
//  Person.swift
//  Person Info
//
//  Created by Andrei on 15.03.2023.
//

import Foundation

class Person {
    
    // attributes
    var name, years, birthplace, description, image, url: String;
    
    // initializers
    init() {
        self.name    = "";
        self.years = "";
        self.birthplace   = "";
        self.description   = "";
        self.image   = "";
        self.url = "";
    }
    
    init(name: String, years: String, birthplace: String, description: String, image:String, url: String) {
        self.name = name;
        self.years = years;
        self.birthplace = birthplace;
        self.description = description;
        self.image = image;
        self.url = url;
    }
}
