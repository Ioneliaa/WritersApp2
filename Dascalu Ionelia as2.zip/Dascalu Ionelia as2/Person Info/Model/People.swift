//
//  People.swift
//  Person Info
//
//  Created by Andrei on 15.03.2023.
//

import Foundation
import UIKit

class People {
    var data:[Person]
    
    init(data: [Person]){
        self.data = data
    }
    
    init(xmlFileName:String) {
        // make a parsing object
        let xmlPeopleParser = XMLPeopleParser(fileName: xmlFileName)
        xmlPeopleParser.parsing()
        
        // set data
        self.data = xmlPeopleParser.peopleData
    }
    
    func getCount()->Int{return data.count}
    func getPerson(index:Int)->Person{return data[index]}
}
