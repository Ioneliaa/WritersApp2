//
//  XMLPeopleParser.swift
//  Person Info
//
//  Created by Andrei on 15.03.2023.
//

import Foundation

class XMLPeopleParser: NSObject, XMLParserDelegate{
    
    var name: String!
    
    init(fileName:String){self.name = fileName}
    
    // vars and objects needed for parsing
    
    var pName, pYears, pBirthplace, pDescription, pImage, pUrl : String!
    
    var peopleData = [Person]()
    var person: Person!
    
    var elemId = -1
    var passData = false
    
    var parser: XMLParser!
    
    let tags = ["name", "years", "birthplace", "description", "image", "url"]
    
    // delegate methods
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        
        if tags.contains(elementName){
            passData = false
            elemId = -1
        }
        
        if elementName == "person" {
            peopleData.append(Person(name: pName, years: pYears, birthplace: pBirthplace, description: pDescription, image: pImage, url: pUrl))
        }
        
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        
        // check if elementName is in tags
        if(tags.contains(elementName)){
            passData = true
            elemId = tags.firstIndex(of: elementName)!
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        
        if passData {
            switch elemId {
            case 0: pName = string
            case 1: pYears = string
            case 2: pBirthplace = string
            case 3: pDescription = string
            case 4: pImage = string
            case 5: pUrl = string
            default: break
            }
        }
        
    }
    
    // method to parse
    
    func parsing(){
        // get the xml path
        let bundleUrl = Bundle.main.bundleURL
        let fileURL = URL(fileURLWithPath: self.name, relativeTo: bundleUrl)
        
        // make the xmlparser
        parser = XMLParser(contentsOf: fileURL)
        
        // set the delegate and parse
        parser.delegate = self
        parser.parse()
    }
}
