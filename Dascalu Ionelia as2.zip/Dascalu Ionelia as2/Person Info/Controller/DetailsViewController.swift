//
//  DetailsViewController.swift
//  Person Info
//
//  Created by Andrei on 15.03.2023.
//

import UIKit

class DetailsViewController: UIViewController {

    // outlets
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var yearsLabel: UILabel!
    @IBOutlet weak var birthplaceLabel: UILabel!
    @IBOutlet weak var descriptionTextView: UITextView!
    
    // model object
    var personData: Person!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // get the data to populate outlets
        nameLabel.text = personData.name
        yearsLabel.text = personData.years
        birthplaceLabel.text = "Birthplace: " + personData.birthplace
        descriptionTextView.text = personData.description
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
     */
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "webSegue" {
            
            // Get the new view controller using segue.destination.
            let destController = segue.destination as! WebViewController
            
            // Pass the data object to the new view controller.
            destController.personData = personData
        }
    }
    

}
