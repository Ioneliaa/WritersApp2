//
//  TableViewController.swift
//  Person Info
//
//  Created by Andrei on 15.03.2023.
//

import UIKit

class TableViewController: UITableViewController, UISearchBarDelegate {

    // outlets
    @IBOutlet weak var searchBar: UISearchBar!
    
    // model data
    var peopleData: People!
    var filteredData: People!
    var typeOfTableView: Bool!
    
    func getData(){
        do
        {
            var dbPeople = [DBPerson]()
            var dbFavoritePeople = [DBFavoritePerson]()
            
            if typeOfTableView == false{
                dbPeople = try CoreDataManager.sharedManager.persistentContainer.viewContext.fetch(DBPerson.fetchRequest())
                peopleData = People(data: CoreDataManager.sharedManager.transformEntitiesToModels(data: dbPeople))
                
                if peopleData.data.isEmpty{
                    var bdPeople = [DBPerson]()
                    
                    var appContext = CoreDataManager.sharedManager.persistentContainer.viewContext
                    bdPeople = try! appContext.fetch(DBPerson.fetchRequest())
                    
                    if bdPeople.isEmpty {
                        let personXmlData = People(xmlFileName: "people.xml")
                        
                        for person in personXmlData.data{
                            var newPerson = DBPerson(context: appContext)
                            
                            newPerson.personName = person.name
                            newPerson.personYears = person.years
                            newPerson.personBirthplace = person.birthplace
                            newPerson.personDescription = person.description
                            newPerson.personImage = person.image
                            newPerson.personUrl = person.url
                            
                            try! appContext.save()
                        }
                    }
                    
                    bdPeople = try! appContext.fetch(DBPerson.fetchRequest())
                    var people = People(data: [])
                    people.data = CoreDataManager.sharedManager.transformEntitiesToModels(data: bdPeople)
                }
            }
            else{
                dbFavoritePeople = try CoreDataManager.sharedManager.persistentContainer.viewContext.fetch(DBFavoritePerson.fetchRequest())
                peopleData = People(data: CoreDataManager.sharedManager.transformEntitiesToModels(data: dbFavoritePeople))
            }
            
            self.filteredData = People(data: peopleData.data)
        }
        catch {

        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getData()
        searchBar.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(false)
        
        getData()
        self.tableView.reloadData()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return filteredData.getCount()
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        // Configure the cell...
        let personData = filteredData.getPerson(index: indexPath.row)
        cell.textLabel?.text = personData.name
        cell.detailTextLabel?.text = personData.years
        cell.imageView?.image = UIImage(named: personData.image)

        return cell
    }
    
    override func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
    
        let favoriteAction = UIContextualAction(style: .normal, title: "Favorite") { (action, view, completitionHandler) in
            
            do
            {
                var people = try CoreDataManager.sharedManager.persistentContainer.viewContext.fetch(DBPerson.fetchRequest()) as! [DBPerson]
                var favoritePeople = try CoreDataManager.sharedManager.persistentContainer.viewContext.fetch(DBFavoritePerson.fetchRequest()) as! [DBFavoritePerson]
                
                var alreadyExists: Bool = false

                if !favoritePeople.isEmpty{
                    for i in 0...favoritePeople.count - 1{
                        if favoritePeople[i].favoritePersonName == people[indexPath.row].personName{
                            alreadyExists = true
                        }
                    }
                }
                
                if alreadyExists == false {
                
                    var favoritePerson = DBFavoritePerson(context: CoreDataManager.sharedManager.persistentContainer.viewContext)
                
                    favoritePerson.favoritePersonName = people[indexPath.row].personName
                    favoritePerson.favoritePersonYears = people[indexPath.row].personYears
                    favoritePerson.favoritePersonBirthplace = people[indexPath.row].personBirthplace
                    favoritePerson.favoritePersonDescription = people[indexPath.row].personDescription
                    favoritePerson.favoritePersonImage = people[indexPath.row].personImage
                    favoritePerson.favoritePersonUrl = people[indexPath.row].personUrl
                                
                    self.peopleData.data = CoreDataManager.sharedManager.transformEntitiesToModels(data: people)
                    self.filteredData.data = CoreDataManager.sharedManager.transformEntitiesToModels(data: people)
                
                    try CoreDataManager.sharedManager.persistentContainer.viewContext.save()
                }
            }
            catch {

            }
        }
        
        favoriteAction.backgroundColor = UIColor(red: 1, green: 0.8, blue: 0, alpha: 1.0)
        if typeOfTableView == false {
            return UISwipeActionsConfiguration(actions: [favoriteAction])
        }
        else {
            return nil
        }
    }
    
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
    
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { (action, view, completitionHandler) in
            
            do
            {
                if(self.typeOfTableView == false){
                    var people = try CoreDataManager.sharedManager.persistentContainer.viewContext.fetch(DBPerson.fetchRequest()) as! [DBPerson]
                
                    CoreDataManager.sharedManager.persistentContainer.viewContext.delete(people[indexPath.row])
                    people.remove(at: indexPath.row)
                
                    self.peopleData.data = CoreDataManager.sharedManager.transformEntitiesToModels(data: people)
                    self.filteredData.data = CoreDataManager.sharedManager.transformEntitiesToModels(data: people)
                
                    tableView.deleteRows(at: [indexPath], with: .fade)
                    try CoreDataManager.sharedManager.persistentContainer.viewContext.save()
                }
                else{
                    var favoritePeople = try CoreDataManager.sharedManager.persistentContainer.viewContext.fetch(DBFavoritePerson.fetchRequest()) as! [DBFavoritePerson]
                
                    CoreDataManager.sharedManager.persistentContainer.viewContext.delete(favoritePeople[indexPath.row])
                    favoritePeople.remove(at: indexPath.row)
                
                    self.peopleData.data = CoreDataManager.sharedManager.transformEntitiesToModels(data: favoritePeople)
                    self.filteredData.data = CoreDataManager.sharedManager.transformEntitiesToModels(data: favoritePeople)
                
                    tableView.deleteRows(at: [indexPath], with: .fade)
                    try CoreDataManager.sharedManager.persistentContainer.viewContext.save()
                }
            }
            catch {

            }
        }
        
        return UISwipeActionsConfiguration(actions: [deleteAction])
        
    }
    
    // MARK: Search Bar config
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        filteredData.data = []
        
        if searchText == "" {
            filteredData = People(data: peopleData.data)
        }
        else {
            for person in peopleData.data {
                if person.name.lowercased().contains(searchText.lowercased()) {
                    filteredData.data.append(person)
                }
            }
        }
        
        self.tableView.reloadData()
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if(segue.identifier == "personSegue") {
            
            // Get the new view controller using segue.destination.
            let destController = segue.destination as! PersonViewController
        
            // Pass the selected object to the new view controller.
            destController.peopleData = peopleData
            let indexPath = tableView.indexPath(for: sender as! UITableViewCell)
            
            // destController.personData = peopleData.getPerson(index: indexPath.row)
            
            var index = 0
            for person in peopleData.data {
                if person.name == filteredData.data[indexPath!.row].name{
                    destController.index = index
                }
                index += 1
            }
        }
    }

}
