import Foundation
import UIKit

class CreatePersonViewController: UIViewController{

    @IBOutlet weak var nameTB: UITextField!
    @IBOutlet weak var yearsTB: UITextField!
    @IBOutlet weak var birthplaceTB: UITextField!
    @IBOutlet weak var descriptionTB: UITextField!
    @IBOutlet weak var imageTB: UITextField!
    @IBOutlet weak var urlTB: UITextField!
    
    override func viewDidLoad() {
        imageTB.text = "default-image.png"
        urlTB.text = "https://www.wikipedia.org"
    }
    
    @IBAction func AddPerson(_ sender: UIButton) {
        
        var appContext = CoreDataManager.sharedManager.persistentContainer.viewContext
        
        var dbPerson = DBPerson(context: appContext)
        dbPerson.personName = nameTB.text
        dbPerson.personYears = yearsTB.text
        dbPerson.personBirthplace = birthplaceTB.text
        dbPerson.personDescription = descriptionTB.text
        dbPerson.personImage = imageTB.text
        dbPerson.personUrl = urlTB.text
        
        try! appContext.save()
        
        CoreDataManager.sharedManager.contextHasChanged = true
        
        _ = navigationController?.popViewController(animated: true)
    }
}
