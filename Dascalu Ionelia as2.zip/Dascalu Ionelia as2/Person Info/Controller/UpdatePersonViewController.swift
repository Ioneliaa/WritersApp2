import Foundation
import UIKit

class UpdatePersonViewController: UIViewController{
    
    var personData: Person!
    
    @IBOutlet weak var nameTB: UITextField!
    @IBOutlet weak var yearsTB: UITextField!
    @IBOutlet weak var birthplaceTB: UITextField!
    @IBOutlet weak var descriptionTB: UITextField!
    @IBOutlet weak var imageTB: UITextField!
    @IBOutlet weak var urlTB: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nameTB.text = personData.name
        yearsTB.text = personData.years
        birthplaceTB.text = personData.birthplace
        descriptionTB.text = personData.description
        imageTB.text = personData.image
        urlTB.text = personData.url
    }
    
    @IBAction func updatePerson(_ sender: UIButton) {
        var appContext = CoreDataManager.sharedManager.persistentContainer.viewContext
        
        var dbPeople = try! CoreDataManager.sharedManager.persistentContainer.viewContext.fetch(DBPerson.fetchRequest()) as! [DBPerson]
        
        for i in 0...dbPeople.count{
            if dbPeople[i].personName == personData.name{
                dbPeople[i].personName = nameTB.text
                dbPeople[i].personYears = yearsTB.text
                dbPeople[i].personBirthplace = birthplaceTB.text
                dbPeople[i].personDescription = descriptionTB.text
                dbPeople[i].personImage = imageTB.text
                dbPeople[i].personUrl = urlTB.text
                break
            }
        }
        
        try! appContext.save()
        
        CoreDataManager.sharedManager.contextHasChanged = true
        
        _ = navigationController?.popViewController(animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "editedPersonSegue" {
            
            // Get the new view controller using segue.destination.
            let destController = segue.destination as! PersonViewController
            
            // Pass the data object to the new view controller.
            destController.personData = personData
        }
    }
    
}

