//
//  PersonViewController.swift
//  Person Info
//
//  Created by Andrei on 15.03.2023.
//

import UIKit

class PersonViewController: UIViewController {

    // outlets
    
    @IBOutlet weak var personImageView: UIImageView!
    @IBOutlet weak var personNameLabel: UILabel!
    
    @IBAction func previousPerson(_ sender: Any) {
        index = index == 0 ? peopleData.getCount()-1 : index-1
        updateViews()
    }
    
    @IBAction func nextPerson(_ sender: Any) {
        index = index == peopleData.getCount()-1 ? 0 : index+1
        updateViews()
    }
    
    
    // model object
    var peopleData: People!
    var personData: Person!
    
    // other vars and methods
    var index = 0
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(false)
        updateViews()

    }
    
    func updateViews(){
        // get person
        var dbPeople = try! CoreDataManager.sharedManager.persistentContainer.viewContext.fetch(DBPerson.fetchRequest()) as! [DBPerson]
        peopleData = People(data: CoreDataManager.sharedManager.transformEntitiesToModels(data: dbPeople))

        if peopleData.getPerson(index: index).name == "RANDOM" {
            personData = peopleData.getPerson(index: Int.random(in: 0..<peopleData.data.count))
        }
        else
        {
            personData = peopleData.getPerson(index: index)
        }
            
        // update views
        personNameLabel.text = personData.name
        personImageView.image = UIImage(named: personData.image)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // put data on outlets
        updateViews()
    }
    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "personDetailsSegue" {
            
            // Get the new view controller using segue.destination.
            let destController = segue.destination as! DetailsViewController
            
            // Pass the data object to the new view controller.
            destController.personData = personData
        }
        
        if segue.identifier == "editPersonSegue" {
            
            // Get the new view controller using segue.destination.
            let destController = segue.destination as! UpdatePersonViewController
            
            // Pass the data object to the new view controller.
            destController.personData = personData
        }
    }

}
