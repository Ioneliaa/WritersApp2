import Foundation
import UIKit

class MenuViewController: UIViewController{
    
    var peopleData: People!
    
    @IBOutlet weak var createPersonButton: UIButton!
    @IBOutlet weak var seePersonButton: UIButton!
    
    @IBAction func reset(_ sender: Any) {
        var dbPeople = try! CoreDataManager.sharedManager.persistentContainer.viewContext.fetch(DBPerson.fetchRequest()) as! [DBPerson]
        
        var dbFavoritePeople = try! CoreDataManager.sharedManager.persistentContainer.viewContext.fetch(DBFavoritePerson.fetchRequest()) as! [DBFavoritePerson]
        
        var appContext = CoreDataManager.sharedManager.persistentContainer.viewContext
        
        for person in dbPeople {
            appContext.delete(person)
        }
        
        for favoritePerson in dbFavoritePeople {
            appContext.delete(favoritePerson)
        }
        
        try! appContext.save()
        
        let personXmlData = People(xmlFileName: "people.xml")
        
        for person in personXmlData.data{
            var newPerson = DBPerson(context: appContext)
            
            newPerson.personName = person.name
            newPerson.personYears = person.years
            newPerson.personBirthplace = person.birthplace
            newPerson.personDescription = person.description
            newPerson.personImage = person.image
            newPerson.personUrl = person.url
            
            try! appContext.save()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if(segue.identifier == "peopleSegue") {
            let destController = segue.destination as! TableViewController
            
                do{
                    var dbPeople = try CoreDataManager.sharedManager.persistentContainer.viewContext.fetch(DBPerson.fetchRequest()) as! [DBPerson]
                    var people = People(data: CoreDataManager.sharedManager.transformEntitiesToModels(data: dbPeople))
                    destController.peopleData = people
                    destController.typeOfTableView = false
                }
                catch {
                    
                }
            }
        
        if(segue.identifier == "favoritePeopleSegue") {
            let destController = segue.destination as! TableViewController
            
                do{
                    var dbFavoritePeople = try CoreDataManager.sharedManager.persistentContainer.viewContext.fetch(DBFavoritePerson.fetchRequest()) as! [DBFavoritePerson]
                    var favoritePeople = People(data: CoreDataManager.sharedManager.transformEntitiesToModels(data: dbFavoritePeople))
                    destController.peopleData = favoritePeople
                    destController.typeOfTableView = true
                }
                catch {
                    
                }
            }
        }
}

    

